let names = ["Alice", "Bob", "Charlie", "David", "Emily", "Frank", "Grace", "Henry", "Isabella", "Jack", "Kate", "Liam", "Mia", "Noah", "Olivia", "Peter", "Quinn", "Rose", "Sophia", "Thomas", "Uma", "Victoria", "William", "Xander", "Yara", "Zoe"]

var bigramCounts = [String: Int]()
var totalBigrams = 0

// 1. Чтение данных в структуры данных удобных для высчитывания вероятностей
for name in names {
    let nameChars = Array(name)
    for i in 0..<nameChars.count-1 {
        let bigram = "\(nameChars[i])\(nameChars[i+1])"
        if let count = bigramCounts[bigram] {
            bigramCounts[bigram] = count + 1
        } else {
            bigramCounts[bigram] = 1
        }
        totalBigrams += 1
    }
}

// 2. Высчитывание вероятности всех существующих биграмм
var bigramProbabilities = [String: Double]()
for (bigram, count) in bigramCounts {
    bigramProbabilities[bigram] = Double(count) / Double(totalBigrams)
}

// 3. Выбор случайной буквы из выборки как первой буквы имени
func getRandomFirstLetter() -> Character {
    let firstLetters = names.map { $0.first! }
    let randomIndex = Int.random(in: 0..<firstLetters.count)
    return firstLetters[randomIndex]
}

// 4. Генерация имени на основе биграмм
func generateName() -> String {
    var name = String(getRandomFirstLetter())
    while let lastChar = name.last, let nextChar = getNextChar(after: lastChar) {
        name.append(nextChar)
    }
    return name
}

func getNextChar(after char: Character) -> Character? {
    var candidates = [Character]()
    for (bigram, probability) in bigramProbabilities {
        if bigram.first == char {
            candidates.append(bigram.last!)
        }
    }
    if candidates.isEmpty {
        return nil
    } else {
        let probabilities = candidates.map { bigramProbabilities["\(char)\($0)"]! }
        let randomIndex = weightedRandom(probabilities: probabilities)
        return candidates[randomIndex]
    }
}

func weightedRandom(probabilities: [Double]) -> Int {
    let sum = probabilities.reduce(0, +)
    let randomValue = Double.random(in: 0..<sum)
    var cumulativeProbability = 0.0
    for (index, probability) in probabilities.enumerated() {
        cumulativeProbability += probability
        if randomValue < cumulativeProbability {
            return index
        }
    }
    return probabilities.count - 1
}

var generator = generateName()
print(generator)
